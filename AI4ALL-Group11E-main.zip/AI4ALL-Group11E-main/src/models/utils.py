"""
utils.py
Utility functions for model training and evaluation.
"""

# TODO: Add utility functions for metrics, saving/loading models, etc.

def compute_metrics(y_true, y_pred):
    """
    Computes evaluation metrics (accuracy, precision, recall, F1).
    Args:
        y_true: Ground truth labels
        y_pred: Predicted labels
    Returns:
        dict: Metrics
    """
    # TODO: Implement metrics
    return {} 